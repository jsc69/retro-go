[![Build Status](https://travis-ci.org/libretro/beetle-ngp-libretro.svg?branch=master)](https://travis-ci.org/libretro/beetle-ngp-libretro)
[![Build status](https://ci.appveyor.com/api/projects/status/cbyyvbdbv1yc8yst/branch/master?svg=true)](https://ci.appveyor.com/project/bparker06/beetle-ngp-libretro/branch/master)

# Beetle NeoGeo Pocket